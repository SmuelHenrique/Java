package dao;

import beans.Cliente;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {
    private Connection con;
    
    public ClienteDAO(){
        this.con = Conexao.getConexao();
    }
    
    public void inserir(Cliente c) throws Exception {
        String sql = "INSERT INTO cliente (nome) VALUES (?)";
        
        try {
            PreparedStatement stmt = this.con.prepareStatement(sql);
            stmt.setString(1, c.getNome());
            stmt.execute();
        } catch (Exception e) {
            throw new Exception("Erro ao inserir cliente: " + e.getMessage());
        }
    }
    
    public List<Cliente> getClientes() throws Exception{
        List<Cliente> lista = new ArrayList();
        
        String sql = "SELECT * FROM cliente";
        try {
            PreparedStatement stmt = this.con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                Cliente c = new Cliente();
                c.setId(rs.getInt("id"));
                c.setNome(rs.getString("nome"));
                
                lista.add(c);
            }
            return lista;
        } catch (Exception e) {
            throw  new Exception("Erro ao buscar cliente" + e.getMessage());
        }
    }
}
